import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm';
import { SUPABASE_URL, SUPABASE_KEY } from './config.js';

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

const map = L.map('map').setView([34.5, 12.5], 6);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

async function fetchBoats() {
  const { data, error } = await supabase.from('boat_incidents').select('*');
  if (error) return console.error('Fetch error:', error);

  data.forEach(boat => {
    const marker = L.marker([boat.latitude, boat.longitude]).addTo(map);
    marker.bindPopup(`
      <strong>ID:</strong> ${boat.id}<br/>
      <strong>Status:</strong> ${boat.status}<br/>
      <strong>Type:</strong> ${boat.type}<br/>
      <strong>Size:</strong> ${boat.size}<br/>
      <strong>Reported:</strong> ${new Date(boat.timestamp).toLocaleString()}
    `);

    if (boat.drift_path) {
      const path = boat.drift_path.map(p => [p.lat, p.lon]);
      L.polyline(path, { color: 'blue' }).addTo(map);
    }
  });
}

fetchBoats();

supabase.channel('realtime:boat_incidents')
  .on('postgres_changes', { event: '*', schema: 'public', table: 'boat_incidents' }, fetchBoats)
  .subscribe();